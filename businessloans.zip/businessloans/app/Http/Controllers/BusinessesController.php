<?php

namespace App\Http\Controllers;
use App\Business;
use Illuminate\Http\Request;

class BusinessesController extends Controller
{
    public function show(Business $business){
      //$business = Business::find($name);

      return view('businesses.show', ['business' => $business]);
    }

    public function index(){
      $businesses = Business::all();

      return view('businesses.index', ['businesses' => $businesses]);
    }
}
