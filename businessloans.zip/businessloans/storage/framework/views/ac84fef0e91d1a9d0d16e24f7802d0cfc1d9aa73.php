
<?php $__env->startSection('content'); ?>
<div id="wrapper">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>These are the calculations</h2>
      </div>
			<p><img src="images/banner.jpg" alt="" class="image image-full" /> </p>
			$avgrec = DB::table('businesses')
	    ->where('loan_type', 'Recruit new staff')
	    ->groupBy('loan_type')
	    ->avg('loan_amount');
		</div>

	</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Laravel/businessloans/resources/views/calculations.blade.php ENDPATH**/ ?>