<?php $__env->startSection('header'); ?>
<div id="header-featured">
  <div id="banner-wrapper">
    <div id="banner" class="container">
      <h2>Business Loans</h2>

      <a href="/businesses" class="button">Find our businesses</a> </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Laravel/businessloans/resources/views/welcome.blade.php ENDPATH**/ ?>