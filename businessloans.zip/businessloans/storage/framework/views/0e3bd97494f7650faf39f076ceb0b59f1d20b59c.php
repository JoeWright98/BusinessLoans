

<?php $__env->startSection('content'); ?>
<div id="wrapper">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2><?php echo e($business->name); ?></h2>
      </div>
			<p><img src="images/banner.jpg" alt="" class="image image-full" /> </p>
			<p>Loan type: <?php echo e($business->loan_type); ?></p>
			<p>Loan amount: £<?php echo e($business->loan_amount); ?></p>
		</div>

	</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Laravel/businessloans/resources/views/businesses/show.blade.php ENDPATH**/ ?>