@extends('layout')

@section('header')
<div id="header-featured">
  <div id="banner-wrapper">
    <div id="banner" class="container">
      <h2>Business Loans</h2>

      <a href="/businesses" class="button">Find our businesses</a> </div>
  </div>
</div>
</div>
@endsection
